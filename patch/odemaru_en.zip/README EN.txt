OOOOOOOOOOOOOOOOOOOOO
O                   O
O Multi's Going Out O
O   Odekake Multi   O
O                   O
OOOOOOOOOOOOOOOOOOOOO

P/ECE Translation	v1.00
PC Translation		v0.90

-- IMPORTANT --

This game requires a real Aquaplus P/ECE in order to enjoy properly. autch has developed a P/ECE emulator, but it doesn't support save games as of the time I'm writing this.

The most comon places I see them for sale online are Suruga-ya, JDirect Auctions, and Mercari JP.

Once you have one, you'll need to take some extra steps to make sure it will run on your machine. If you're using 64-bit windows or macOS/Linux, please reference one of the guides below:

64-bit Windows:	https://qiita.com/autch/items/7244f6b56d910df841f8 
macOS/Linux:	https://qiita.com/zurachu/items/468b10312c812ad854d8

Please note that while transferring files to and from the P/ECE on macOS and Linux appears to be possible, this translation is intended for use only on Windows.

-- Installation --

Assuming your P/ECE is readable by your PC, just run "Multi's Going Out EN.exe".

-- How to Play --

After launching, you may get a video codec error. As of the time I'm writing this, I'm not sure how to fix it, but it's safe to just ignore. You can view the OP and ED in the 'mov' folder using something like VLC.

On the title screen, you should see two options
	The top one installs the game to your P/ECE and starts the prologue sequence.
	The bottom one reads existing save data on your P/ECE

Odemaru is a game that is played between your P/ECE and PC.
*On the former, you take Multi out for walks, find items, improve her stats, and participate in the Robomaid Challenge.
*On the latter, you send rare items Multi finds back to the lab for identification. There's also a special epilogue scene that unlocks once you've beaten the main story on P/ECE.

I am currently working on a full translation of the manual. It's not ready yet, but it is live on my blog site at:

https://btuberbilly.github.io/doujinarchive/odemaru/

-- Note --

2025/06/25 - Billy

Thank you for checking out my translation of Multi's Going Out. This project would not have been possible for me to finish in a timely manner without the help of prolific P/ECE enthusiast, autch. Their assistance on the game's .scr scenario files was invaluable to me, and I seriously cannot thank them enough.

This project is the culmination of many months of work and research, and is my first "big" project.

I am writing this shortly after finishing the last of the text I wanted to translate. It still feels surreal, and I'm a little nervous about sending something of this size out into the wild.

This game has fascinated me since I learned about it last year. Seeing a P/ECE for the first time was like "What do you mean Aquaplus released a handheld console, bundled it with an SDK, and made lots of unique software for it? That's amazing!".

The thing that finally sent me over was the announcement of ToHeart's remake and the subsequent English version confirmation. Once I saw that, I knew I didn't want to keep Odemaru to myself.

So here it is: Multi's Going Out v1.00/0.90. Please enjoy, and never stop moving forward.